=======
Credits
=======

Development of FASTELL code
---------------------------
Rennan Barkana <http://wise-obs.tau.ac.il/~barkana/codes.html>


Development Lead of Python Wrapper
----------------------------------

* Simon Birrer <simon.birrer@phys.ethz.ch>
* Joel Akeret <jakeret@phys.ethz.ch>

Contributors
------------

None yet. Why not be the first?